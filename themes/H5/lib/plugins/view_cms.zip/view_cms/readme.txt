=== View CMS ===
Contributors: Jiang Hongfei
Donate link: http://blog.milandinic.com/donate/
Tags: CMS
Requires at least: 3.5
Tested up to: 3.8
Stable tag: 1.0

A CMS to build small corporate website

== Description ==

[Plugin homepage](http://blog.milandinic.com/wordpress/plugins/disable-google-fonts/) | [Plugin author](http://blog.milandinic.com/) | [Donate](http://blog.milandinic.com/donate/)

A CMS to build small corporate website

== Installation ==

1. Upload `view_cms` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
